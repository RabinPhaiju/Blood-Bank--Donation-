		<img src="../images/logo.png" height="65px;" style="float: left;">
		<h1 style="text-align: center;">Rakta Sanchar (Blood Bank)</h1>
		<p style="float: right; margin-right: 10px; margin-top: -20px;">User: <?=$_SESSION['username']?></p>
        <h1 style="float: right; margin-top: -55px; margin-right: -50px;" ><a href="logout.php" title="Logout"><i class="fa fa-sign-out"></i></a></h1>

	
